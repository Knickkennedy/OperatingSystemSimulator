public enum InstructionType {
    CALCULATE, IO, YIELD
}
